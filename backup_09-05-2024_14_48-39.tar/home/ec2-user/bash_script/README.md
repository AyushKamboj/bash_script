# bash_script
practice bash scripting
